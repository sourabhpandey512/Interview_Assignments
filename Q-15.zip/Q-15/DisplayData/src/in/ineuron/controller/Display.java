package in.ineuron.controller;

import java.io.IOException;

import java.io.PrintWriter;
import java.io.IOException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import in.ineuron.util.JdbcUtil;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/test")
public class Display extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		int id=Integer.parseInt(request.getParameter("sid"));
		
		Connection connection = null;
		PreparedStatement pstmt = null;
		ResultSet resultSet = null;
		int Sid=0,Sage=0;
		String Sname=null,Saddress=null;
		
		String sqlSelectQuery = "select id,name,age,address from student where id = ?";
		

		try {
			connection = JdbcUtil.getJdbcConnection();

			if (connection != null)
				pstmt = connection.prepareStatement(sqlSelectQuery);

			if (pstmt != null)
				pstmt.setInt(1, id);

			if (pstmt != null) {
				resultSet = pstmt.executeQuery();
			}

			if (resultSet != null) {

				if (resultSet.next()) {
					

					// copy resultSet data to student object
					 Sid=resultSet.getInt(1);
					 Sname=resultSet.getString(2);
					 Sage=resultSet.getInt(3);
					 Saddress=resultSet.getString(4);

					
				}

			}

		} catch (SQLException | IOException e) {
			e.printStackTrace();
		}
		

 out.println("<table style=' color:green; text-align:center; border:1px solid black;'>");
 out.println("<tr> <th> ID </th><br><br>");
 out.println("<<th> NAME </th><br><br> ");
 out.println("<th> AGE </th><br><br> ");
 out.println("<th> ADDRESS </th> </tr><br><br>");
 out.println("<tr><td> "+Sid+" </td>");
 out.println("<td> "+ Sname+" </td>");
 out.println("<td> "+ Sage+" </td>");
 out.println("<td> "+ Saddress+" </td>");
 out.println("</tr></table> ");
 
 
 
 
 
 
 
		
	}

}
