package in.ineuron.controller;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Scanner;
import java.io.IOException;
public class TestApp {
public static void main(String args[])throws Exception{
	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	while(true) {
		System.out.println("1. Create");
		System.out.println("2. Read");
		System.out.println("3. Update");
		System.out.println("4. Delete");
		System.out.println("5. Exit");
		System.out.print("ENTER UR Choice, ENTER[1,2,3,4,5]:: ");
		String option=br.readLine();
		switch(option){
		case"1":
			insertOperation();
			break;
		case"2":
			selectOperation();
			break;
		case"3":
			updateRecord();
			break;
		case"4":
			deleteRecord();
			break;
		case"5":
			System.out.println("*****Thanks for using the appication*****");
			System.exit(0);
		default:
			System.out.println("Invalid option,try again");
			break;
				
		}
		
	}
	
}
private static void updateRecord() throws IOException {
BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
System.out.println("Enter the StudentId to be updated:: ");
String sid=br.readLine();
IStudentService studentService= StudentServiceFactory.getStudentService();
Student student=studentService.searchStudent(Integer.parseInt(sid));
if(student!=null) {
	Student newStudent=new Student();
	System.out.println("Student id is:: "+student.getSid());
	newStudent.setSid(student.getSid());
	System.out.print("Student OLD name is :: "student.getSname()+" Enter new name:: ");
	String newName=br.readLine();
	if(newName.equals("")||newName.equals("")) {
		newStudent.setSname(student.getSname());}
		else {
			newStudent.setSname(newName);
		}
	System.out.println("Student OLD age is::  "+student.getSage()+" Enter new age:: ");
	String newAge=br.readLine();
	if(newAge.equals("")||newAge.equals("")) {
	newStudent.setSage(student.getSage());
	
	}
	else {
		newStudent.setSage(Integer.parseInt(newAge));
	}
	System.out.println("Student OLD Address is::  "+student.getSaddress()+" Enter new address");
	String newAddress=br.readLine();
	if(newAddress.equals("")||newAddress.equals("")) {
		newStudent.setSaddress(student.getSaddress());
	}
	else {
		newStudent.setSaddress(newAddress);
	}
	System.out.println("New Object Data is :: "+newStudent);
	System.out.println();
	String status=studentService.updateStudent(newStudent);
	if(status.equals("success")) {
		System.out.println("Record updated Successfully");
	}
	else {
		System.out.println("Record updation Failed");
	}
}
else {
	System.out.println("Student record is not available for the given id  "+sid+" for updation");
}
}
private static void deleteRecord() {
	Scanner scanner=new Scanner(System.in);
	System.out.println("Enter the Student Id to be deleted");
	int sid=scanner.nextInt();
	IStudentService studentService=StudentServiceFactory.getStudentService();
	String msg=studentService.deleteStudent(sid);
	if(msg.equalsIgnoreCase("success")) {
		System.out.println("Record deleted successfully");
		
	}
	else if(msg.equalsIgnoreCase("not found")) {
		System.out.println("Records not found for the given ID "+sid);
	}
	else {
		System.out.println("Record Deletion Failed");
	}
		
	
}
private static void selectOperation() {
	Scanner scanner=new Scanner(System.in);
	System.out.println("Enter the Student ID:: ");
	int sid= scanner.nextInt();
	IStudentService studentService= StudentServiceFactory.getStudentService();
	Student std=studentService.searchStudent(sid);
	if(std!=null) {
		System.out.println(std);
		System.out.println("SID\tSNAME\tSAGE\tSADDR");
		System.out.println(std.getSid()+" \t"+std.getSname()+ "\t" +std.getSage() +"\t" +std.getSaddress());
		
	}
	else {
		System.out.println("Record not found for the given id :: "+sid);
	}
}
private static void insertOperation() {
	IStudentService studentService=StudentServiceFactory.getStudentService();
	Scanner scanner=new Scanner(System.in);
	System.out.print("Enter the Student name:: ");
	String sname=scanner.next();
	System.out.println("Enter the Student age :: ");
	int sage=scanner.nextInt();
	System.out.println("Enter the Student address");
	String saddress=scanner.next();
	String msg=studentService.addStudent(sname,sage,saddress);
	if(msg.equalsIgnoreCase("success")) {
		System.out.println("record inserted successfully");
		
	}
	else {
		System.out.println("Record Insertion Failed....");
	}
	
}
}
