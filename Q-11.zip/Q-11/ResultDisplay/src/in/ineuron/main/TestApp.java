package in.ineuron.main;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Scanner;


import in.ineuron.util.JdbcUtil;



public class TestApp {

	public static void main(String[] args) {

		Connection connection = null;
		PreparedStatement pstmt = null;
		ResultSet resultSet = null;


			String sqlInsertQuery = "select * from student";
			try {
				connection = JdbcUtil.getJdbcConnection();

				if (connection != null)
					pstmt = connection.prepareStatement(sqlInsertQuery);
				if(pstmt!=null)
				resultSet=pstmt.executeQuery();
				
				System.out.println("id\t\tname\t\tage\t\taddress");
                if(resultSet!=null) {
				while (resultSet.next()) {

					int id= resultSet.getInt("id");
					String name=resultSet.getNString("name");
					int age= resultSet.getInt("age");
					String address=resultSet.getNString("address");
					System.out.println(id + "\t\t" + name
                            + "\t\t" + age+"\t\t" +address);
					}
                }
                else
                	System.out.println("Record not found");
			} catch (SQLException | IOException e) {
				e.printStackTrace();
			}

			
		}}

